function showUser(id) {
  if (id < 0) {
    throw new Error('ID must not be negative');
  }
  return { id: id };
}

function showUsers(ids) {
  var users = [];
  for (var i = 0; i < ids.length; i++) {
    try {
      var user = showUser(ids[i]);
      users.push(user);
    } catch (error) {
      console.error('Error:', error.message);
    }
  }
  return users;
}

var users = showUsers([7, -12, 44, 22]);
console.log(users);
