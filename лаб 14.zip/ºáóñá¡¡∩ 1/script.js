function calcRectangleArea(width, height) {
    if (typeof width !== 'number' || typeof height !== 'number') {
      throw new Error('Parameters must be numbers');
    }
    return width * height;
  }
  
  try {
    var width = Number(prompt('Enter the width:'));
    var height = Number(prompt('Enter the height:'));
    var area = calcRectangleArea(width, height);
    console.log('Rectangle area:', area);
  } catch (error) {
    console.error('Error:', error.message);
  }
  