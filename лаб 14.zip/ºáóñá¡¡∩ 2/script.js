function checkAge() {
  var age = prompt('Enter your age:');
  if (age === '') {
    throw new Error('The field is empty! Please enter your age');
  }
  if (isNaN(age)) {
    throw new Error('Invalid input! Please enter a valid number for age');
  }
  if (Number(age) < 14) {
    throw new Error('You are too young to watch this movie');
  }
  console.log('You can watch the movie');
}

try {
  checkAge();
} catch (error) {
  console.error('Error:', error.message);
}
